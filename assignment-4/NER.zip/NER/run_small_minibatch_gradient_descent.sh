#!/bin/sh
python NER.py -d data/ner_small_training.csv -t data/ner_small_test.csv -mgd
