#!/bin/sh
python BigramTester.py -f kafka_model.txt -t data/small.txt
