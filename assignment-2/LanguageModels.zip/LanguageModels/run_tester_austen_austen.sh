#!/bin/sh
python BigramTester.py -f austen_model.txt -t data/austen_test.txt
