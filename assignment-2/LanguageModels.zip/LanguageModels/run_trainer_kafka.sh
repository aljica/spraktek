#!/bin/sh
python BigramTrainer.py -f data/kafka.txt -d kafka_model.txt
