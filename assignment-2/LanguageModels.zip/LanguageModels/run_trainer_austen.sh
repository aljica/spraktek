#!/bin/sh
python BigramTrainer.py -f data/austen_training.txt -d austen_model.txt
